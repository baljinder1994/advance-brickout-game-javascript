# Break the Wall Game

- Press up Arrow Key Left/Right Arrow Key to Move

# Screenshots
![image](https://user-images.githubusercontent.com/72241207/170699747-5c37edeb-534e-4265-8ff7-3e1f37fdbdf8.png)
